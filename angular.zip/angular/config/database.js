module.exports = {
    'url' : 'mongodb://localhost/myApp'
};