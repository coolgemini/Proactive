1. npm install
2. npm install nodemon -g
3. npm start